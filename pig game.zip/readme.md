Click here to live preview : <a href= 'https://jumtech.net/game/pig/'> [LIVE PREVIEW] </a>

Technology used: HTML, CSS , Bootstrap, Vanilla JavaScript
Library used: <a href = 'https://vincentgarreau.com/particles.js/'> particlejs </a>
Used icons : <a href = 'https://ionicons.com/'> ION ICONS </a>

Features:

- Fully responsive
- Cross browser support
- Boostrap 4 classes
- older IE support warnings
- Interactive background particles with mouse pointer

Email: ramrachaim@gmail.com
phone: 8801732900565
website: jumtech.net
